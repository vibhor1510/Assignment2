// var AWS = require('aws-sdk'),
// 	util = require('util');
// // configure AWS
// AWS.config.update({
//     'region': 'us-west-2', //'us-east-1',
//     'accessKeyId': 'AKIAISELWXJOFBKQ6KNA',
//     'secretAccessKey': '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'
// });

// var sqs = new AWS.SQS();

// var params = {
// 	QueueUrl: 'https://sqs.us-west-2.amazonaws.com/942656995689/tweets', /* required */
// 	MaxNumberOfMessages: 1,
// 	MessageAttributeNames: [
// 	  'tweetID'
// 	],
// 	VisibilityTimeout: 0,
// 	WaitTimeSeconds: 0
// };
// sqs.receiveMessage(params, function(err, data) {
// 	if (err) console.log(err, err.stack); // an error occurred
// 	else     console.log(data);           // successful response
// });