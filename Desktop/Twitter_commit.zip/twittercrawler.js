var Twitter = require('twitter');
var MongoClient = require('mongodb').MongoClient;
var Server = require('mongodb').Server;

var dbserver = '52.23.184.73';
var dbport = 27017;
var db;
var client;
var globalWOEID='1';
var usaWOEID='23424977';
var nycWOEID='2459115';
var trendingTopics = [];

var AWS = require('aws-sdk'),
	awsCredentialsPath = './credentials.json',
	util = require('util');
// configure AWS
AWS.config.loadFromPath(awsCredentialsPath);

var sqs = new AWS.SQS();

var stall = true
var twitterStream;

var crawler = function(io) {
	// init database
	var dbClient = new MongoClient(new Server(dbserver, dbport));
	dbClient.open(function(err, client) {
		if(err) {
			console.log(err);
		} else {
			db = client.db('twitt-trend');
			if(!db.collection('tweets')) {
				db.createCollection('tweets', function(err, col) {
					if(err) {
						console.log('Creating collection failed');
					} else {
						console.log('Collection \'tweets\' created');
					}
				});
			}
		}
	});

	// init twitter API
	function init_crawler() {
		client = new Twitter({
			consumer_key: 'Kt3ViXgFKyKl5yUUCxh1Wpanv',
                        consumer_secret: '8NtA53XSNyuyvHoRK8JWlkFd04ChVnvgeKx1ex4HnhhN4bhlDR',
                        access_token_key: '702544459125415937-CjQzqDbO9seNefjIjB2S09uyBgbgkYE',
                        access_token_secret: 'NJG0C7DHtBx422bjqquHtoMp60vDB3HDfzIAT4oSHB2O9'
		});
		
	    // tw.stream('statuses/filter', {'locations':'-180,-90,180,90'}, function(stream) {


	    	//===========================
	    	// client.get('trends/place', {'id':'1'})

	    	//============================

		client.stream('statuses/filter', {'locations':'-180,-90,180,90'}, function(stream) {
			twitterStream = stream;
			stream.on('data', function(tweet) {
				// still receiving data
				stall = false
				// only record tweets with location info
				if(tweet.coordinates && tweet.coordinates.coordinates) {
                                     var outputPoint = {"lat": data.coordinates.coordinates[0],"lng": data.coordinates.coordinates[1]};
                                     socket.broadcast.emit("twitter-stream", outputPoint);
                                     socket.emit('twitter-stream', outputPoint);
					var item = {
						text: tweet.text,
						coordinates: tweet.coordinates.coordinates,
						created_at: new Date(tweet.created_at),
						sentiment: null
					};
					// store in database
					db.collection('tweets').insert(item, function(err, result) {
						if(err) {
							console.log('Inserting doc failed');
						}
						else{
							var params = {
								MessageBody: tweet.text, /* required */
								QueueUrl: 'https://sqs.us-west-2.amazonaws.com/539944485541/sqs', /* required */
								DelaySeconds: 0,
								MessageAttributes: {
								    tweetID: {
								      DataType: 'String', /* required */
								      StringValue: result[0]._id.toHexString()
								    }
								  }
							};
							sqs.sendMessage(params, function(err, data) {
								if (err) console.log(err, err.stack); // an error occurred
								//else     console.log(data);           // successful response
							});
						}
					});
					// push to clients
					// io.emit('data', item);
				}
			});

			stream.on('error', function(error) {
				console.log(error);
			});
		});
	}
	
	init_crawler();

	// get current trends, every 5 minutes (respecting rate-limit of once per 5 minutes) 
	function trending_topics() {
		client.get('trends/place', {'id' : globalWOEID}, function(err, trendsArray, response) {
			if(err) {
				console.log(err);
			}
			var count = 0;
			trendingTopics = [];
			trendsArray[0].trends.forEach(function(trend) {
				count++;
			    // str = str + count + ". " + trend.name + ' \n ';
			    // console.log(count + ". " + trend.name);
				trendingTopics.push(count + ". " + trend.name);
			});
   			io.emit('trending', trendingTopics);
		});
	}
	trending_topics();
	setInterval(trending_topics(), 5*60*1000);
	setInterval(
		function(){
		    console.log( "\n\n=========== EMITTING trendingTopics: "  + trendingTopics);
			io.emit('trending', trendingTopics);
		}, 2*1000);


	// remove old tweets, run every 4hrs
	setInterval(function() {
		// remove tweets older than 4hrs
		var params = {
			created_at: {$lt: new Date(Date.now() - 4*60*60*1000)}
		};
		db.collection('tweets').remove(params, function(err, result) {
			if(err) {
				console.log('Removing old tweets failed');
			} else {
				console.log(result + ' old tweets removed');
			}
		});
	}, 4*60*60*1000);

	// check if no data received in 90 secs
	setInterval(function() {
		if(!stall) {
			stall = true;
			return;
		}
		twitterStream.destroy();
		setTimeout(function() {
			init_crawler();
		}, 90*1000);
	}, 90*1000);

};

module.exports = crawler;
