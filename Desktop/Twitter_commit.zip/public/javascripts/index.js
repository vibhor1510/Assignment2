(function() {
	var map;
	var heatmap;
	var heatmapData = new google.maps.MVCArray();
	var allData = [];

	var filter = false;
	var keywords = [];
        var str = "India";
        
	var markerClusterer;

        var markerImage = "stylesheets/small-dot-icon.png";

	var infoWindow = new google.maps.InfoWindow();

	var sentimentColors = {
		'positive': 'f0ad4e', //'ff7f0e',
		'negative': '5bc0de', //'1f77b4',
		'neutral' : '777'
	};

	var posNum = 0;
	var negNum = 0;
	var neuNum = 0;
        var socket;
        socket = io.connect('http://localhost:3000/');  
        socket.on('twitter-stream', function (data) {
    // add tweet to the heat map array
    var tweetLocation = new google.maps.LatLng(data.lng,data.lat);
    heapmapData.push(data);
  
    // flash tweet location dot on the map
    var image = "stylesheets/small-dot-icon.png";
    var marker = new google.maps.Marker({
      position: tweetLocation,
      map: map,
      icon: image
    });
    setTimeout(function(){
      marker.setMap(null);
    },600);
});
	// load map
	function init_map() {
		var mapOptions = {
			// center: {lat: 37.6, lng: -95.665},
			center: {lat: 28, lng: 20},
        	// zoom: 5
		    zoom: 2,
		    // center: myLatlng,

		    mapTypeId: google.maps.MapTypeId.HYBRID,
		    mapTypeControl: true,
		    mapTypeControlOptions: {
		      style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
		      position: google.maps.ControlPosition.LEFT_BOTTOM
		    } //,
		    // styles: light_grey_style



		};
                
		map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
                
		// heat map
		heatmap = new google.maps.visualization.HeatmapLayer({
			data: heatmapData,
			radius: 25
		});
		heatmap.setMap(map);
		// marker cluster
		markerClusterer = new MarkerClusterer(map, [], {ignoreHidden: true});
                
	}
	google.maps.event.addDomListener(window, 'load', init_map);
     //    setKeywordFiltertest(str);
	function ifSentimentDisplay(d) {
		if($('#posCbox').is(':checked') && d.sentiment > 0 || $('#negCbox').is(':checked') && d.sentiment < 0 || $('#neuCbox').is(':checked') && !d.sentiment) {
			return true;
		} else {
			return false;
		}
	}

	function buildData() {
		var data = {
			mapData: [],
			markers: []
		};
		if(filter) {
			allData.forEach(function(d) {
				d.marker = null;
				var show = true;
				keywords.forEach(function(k) {
					if(d.text.toLowerCase().indexOf(k.toLowerCase()) < 0) {
						show = false;
					}
				});
				if(show && ifSentimentDisplay(d)) {
					var loc = new google.maps.LatLng(d.coordinates[1], d.coordinates[0]);
					data.mapData.push(loc);
					var marker = new google.maps.Marker({ position: loc, icon: markerImage});
					d.marker = marker;
					addPopover(marker, d.text);
					setMarkerColor(marker, d.sentiment);
					data.markers.push(marker);
				}
			});
		} else {
			allData.forEach(function(d) {
				if(ifSentimentDisplay(d)) {
					var loc = new google.maps.LatLng(d.coordinates[1], d.coordinates[0]);
					data.mapData.push(loc);
					var marker = new google.maps.Marker({ position: loc, icon: markerImage});
					d.marker = marker;
					addPopover(marker, d.text);
					setMarkerColor(marker, d.sentiment);
					data.markers.push(marker);
				}
			});
		}
		return data;
	}

	function addPopover(marker, data) {
		google.maps.event.addListener(marker, 'mouseover', function() {
			infoWindow.setContent(data);
			infoWindow.open(map, marker);
		});
		google.maps.event.addListener(marker, 'mouseout', function() {
			infoWindow.setContent('');
			infoWindow.close();
		});
	}

	function setMarkerColor(marker, sentiment) {
		// if(!sentiment || !marker) {
		if(!marker) {
			return;
		}
		var polar = 'neutral';
		if (sentiment > 0) { 
			polar = 'positive';
		} else if (sentiment < 0 ) {
			polar = 'negative';
		}
		// var polar = sentiment >= 0 ? 'positive' : 'negative';
	
		var color = sentimentColors[polar];
		var icon = "https://chart.googleapis.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + color;
		marker.setIcon(icon);
	}

	function refreshNum() {
		$('#pos-num').text(posNum);
		$('#neg-num').text(negNum);
		$('#neu-num').text(neuNum);
	}

        function setKeywordFiltertest(keyword) {
  		filter = true;
  		
  		keywords.length = 0;
  		keywords.push(keyword);
               // filter = false;

        }

        function setKeywordFilter(keyword) {
  		filter = true;
  		//heatmap.setMap(null);
  		keywords.length = 0;
  		keywords.push(keyword);
		markerClusterer = new MarkerClusterer(map, [], {ignoreHidden: true});
              //updateheatmapdata();
                $(document).ready();
  //call function to change heatmapdata
		
  		heatmap = new google.maps.visualization.HeatmapLayer({
		  	data: heatmapData,
		  	radius: 25
		});
  		heatmap.setMap(map);
  		
  		filter = false;
  		keywords.length = 0; 


  //liveTweets = nw google.maps.MVCArray();
  //heatmap = new google.maps.visualization.HeatmapLayer({
    //data: liveTweets,
    //radius: 25
  //});
  //heatmap.setMap(map);
  //socket.emit("filter tweets", keyword);
 
	
	}

	function buildTrendChart() {
		var currentTrend = 0;
		var data; // data to draw the chart
		var newData; // new data to be displayed
		var n; // number of data points to show
		var duration; // time duration for updating line chart
		var now; // the latest time in the chart

		var margin = {top: 20, bottom: 20, left: 40, right: 20},
			width = 400 - margin.left - margin.right,
			height = 250 - margin.top - margin.bottom;

		var x; // x scale
		var y; // y scale
		var line; // d3 line
		var xAxis; // d3 xAxis
		var yAxis; // d3 yAxis
		var timeform = d3.time.format("%X");

		var svg; // canvas
		var xAxisSvg; // x axis svg
		var yAxisSvg; // y axis svg
		var path; // path svg
		var xLabel;
		var yLabel;

		var drawLineChart = function() {
			n = 20;
			duration = 500;
			data = d3.range(n).map(function() { return 0; });
			newData = posNum + negNum == 0 ? 0 : (posNum / (posNum + negNum) - 0.5) * 2;
			now = new Date(Date.now() - duration);

			x = d3.time.scale()
				.domain([now - (n-2)*duration, now - duration])
				.range([0, width]);

			y = d3.scale.linear()
				//.domain([-1, 1])
				.range([height, 0]);

			line = d3.svg.line()
				.interpolate("basis")
				.x(function(d, i) { return x(now - (n - 1 - i) * duration); })
				.y(function(d, i) { return y(d); });

			svg = d3.select("#sentimentTrendChart").append("svg")
				.attr("width", width + margin.left + margin.right)
				.attr("height", height + margin.top + margin.bottom + 20)
				.append("g")
				.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

			svg.append("defs").append("clipPath")
				.attr("id", "trendCurveClip")
				.append("rect")
				.attr("width", width)
				.attr("height", height);

			xAxis = d3.svg.axis().scale(x).orient("bottom");//.tickFormat(timeform);
			yAxis = d3.svg.axis().scale(y).orient("left");

			xAxisSvg = svg.append("g")
				.classed("axis", true)
				.attr("transform", "translate(0," + height/2 + ")")
				.call(xAxis);

			xLabel = xAxisSvg.append("text")
				.classed("axislabel", true)
				.attr("x", width/2)
				.attr("y", 35)
				.attr("text-anchor", "middle")
				.text("Time");

			yAxisSvg = svg.append("g")
				.classed("axis", true)
				.call(yAxis);

			yLabel = yAxisSvg.append("text")
				.classed("axislabel", true)
				.attr("x", -height/2)
				.attr("y", -32)
				.attr("transform", "rotate(-90)")
				.attr("text-anchor", "middle")
				.text("Trend");

			path = svg.append("g")
				.attr("clip-path", "url(#trendCurveClip)")
				.append("path")
				.data([data])
				.classed("line", true)

			tick();
		};

		var tick = function() {
			now = new Date();
			newData = posNum + negNum == 0 ? 0 : (posNum / (posNum + negNum) - 0.5) * 2;
			data.push(newData);

			x.domain([now - (n-2)*duration, now - duration]);
			var limit = Math.abs(d3.max(data)) > Math.abs(d3.min(data)) ? Math.abs(d3.max(data)) : Math.abs(d3.min(data));
			y.domain([-limit, limit]);

			svg.select(".line")
				.attr("d", line)
				.attr("transform", null);

			xAxisSvg.transition()
				.duration(duration)
				.ease("linear")
				.call(xAxis);

			yAxisSvg.transition()
				.duration(duration)
				.ease("linear")
				.call(yAxis);
			
			path.transition()
				.duration(duration)
				.ease("linear")
				.attr("transform", "translate(" + x(now - (n-1)*duration) + ")")
				.each("end", tick);

			data.shift();
		};

		drawLineChart();
	}
        
      //function updateheatmapdata() {
	$(document).ready(function() {
		// fetch tweets from mongo
		$.get('/tweets', function(data) {
                        heatmapData.length = 0;
			data.forEach(function(d) {
                               
                                if(filter) {
				var show = false;
				keywords.forEach(function(k) {
					if(d.text.toLowerCase().indexOf(k.toLowerCase()) >= 0) {
						show = true;
					}
				});
				if(!show)
					return;
			       }
				allData.push(d);
				var loc = new google.maps.LatLng(d.coordinates[1], d.coordinates[0]);
				heatmapData.push(loc);
				//markers.push(new google.maps.Marker({ position: loc}));
				var marker = new google.maps.Marker({ position: loc, icon: markerImage});
				d.marker = marker;
				addPopover(marker, d.text);
				setMarkerColor(marker, d.sentiment);
				if(d.sentiment) {
					if(d.sentiment > 0) {
							posNum++;
					} else if(d.sentiment < 0) {
							negNum++;
					}
					refreshNum();
				} else if(d.sentiment == 0) {
					neuNum++;
					refreshNum();
				}
				markerClusterer.addMarker(marker);
			});
		});
         //}
		// build trend chart
		buildTrendChart();

		// var socket = io();
		var socket = io.connect('http://52.32.222.2:3000/');
		//var socket = io.connect('ws://tweetmap.elasticbeanstalk.com/');
		socket.on('data', function(d) {
			allData.push(d);
			// d.marker = null;
			// if there is a filter
			if(filter) {
				var show = false;
				keywords.forEach(function(k) {
					if(d.text.toLowerCase().indexOf(k.toLowerCase()) >= 0) {
						show = true;
					}
				});
				if(!show)
					return;
			}
			var loc = new google.maps.LatLng(d.coordinates[1], d.coordinates[0]);
			heatmapData.push(loc);

			// if(d.sentiment) {
			// 	d.sentiment >= 0 ? posNum++ : negNum++;
			// 	// alert(posNum + " " + negNum);
			// 	refreshNum();
			// }

			if(d.sentiment) {
				// d.sentiment >= 0 ? posNum++ : negNum++;
				if(d.sentiment > 0) {
						posNum++;
				} else if(d.sentiment < 0) {
						negNum++;
				}
				refreshNum();
			} else if(d.sentiment == 0) {
				neuNum++;
				refreshNum();
			}

			//markers.push(new google.maps.Marker({ position: loc}));
			if($('#markerclusterCbox').is(':checked')) {
				var marker = new google.maps.Marker({ position: loc, icon: markerImage});
				d.marker = marker;
				addPopover(marker, d.text);
				markerClusterer.addMarker(marker);
			} else {
				// flash a marker
				var marker = new google.maps.Marker({
					position: loc,
					map: map,
					icon: markerImage
				});
				setTimeout(function() {
					marker.setMap(null);
				}, 1000);
			}
			setMarkerColor(d.marker, d.sentiment);
		});


		socket.on('trending', function(trendingTopics) {
			// $('#trending').val(trendingTopics);

			$("#trending").empty();
			// $('#trending').text(trendingTopics);
			trendingTopics.forEach(function(topic) {
			    // count++;
			    // str = str + count + ". " + trend.name + '\n';
			    // console.log(count + ". " + trend.name);
    			$("#trending").append('<li><a>' + topic + '</a></li>');

			  })
		});
		// map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);



		// socket.on('sentiment', function(d) {
		// 	var data = null;
		// 	for(var i = 0; i < allData.length; i++) {
		// 		if(allData[i]._id == d._id) {
		// 			data = allData[i];
		// 			break;
		// 		}
		// 	}
		// 	if(data == null)
		// 		return;
		// 	if(d.sentiment) {
		// 		d.sentiment >= 0 ? posNum++ : negNum++;
		// 		refreshNum();
		// 	}
		// 	data.sentiment = d.sentiment;
		// 	setMarkerColor(data.marker, data.sentiment);
		// });

		// filter
		var filterListener = function () {
			// var filterStr = $('#filterInput').val();
			var result;
			markerClusterer.clearMarkers();
			// if(filterStr != '') {
				// keywords = filterStr.trim().split(/\s+/g);
				// filter = true;
				// result = buildData(filter);
			// } else {
				filter = false;
				result = buildData(filter);
			// }
			if($('#heatmapCbox').is(':checked')) {
				heatmapData = new google.maps.MVCArray(result.mapData);
				heatmap.setData(heatmapData);
			}
			if($('#markerclusterCbox').is(':checked')) {
				markerClusterer = new MarkerClusterer(map, result.markers);
			}
		}

		// $('#filterBtn').click(filterListener);
		$('#posCbox').change(filterListener);
		$('#negCbox').change(filterListener);
		$('#neuCbox').change(filterListener);

		// heatmap check
		$('#heatmapCbox').change(function() {
			if($(this).is(':checked')) {
				heatmap.setMap(map);
			} else {
				heatmap.setMap(null);
			}
		});

		// markercluster check
		$('#markerclusterCbox').change(function() {
			if($(this).is(':checked')) {
				var result = buildData();
				markerClusterer = new MarkerClusterer(map, result.markers);
			} else {
				markerClusterer.clearMarkers();
				//markerClusterer.setMap(null);
			}
		});

	});

})();




